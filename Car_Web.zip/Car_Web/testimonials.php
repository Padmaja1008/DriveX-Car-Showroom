<?php
require_once 'config/config.php';
$conn = getDBConnection();

$testimonials = $conn->query("SELECT * FROM testimonials WHERE status = 'active' ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testimonials - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-header">
        <div class="container">
            <h1>Customer Testimonials</h1>
            <p>See what our customers have to say about us</p>
        </div>
    </section>

    <section class="testimonials-page">
        <div class="container">
            <?php if ($testimonials->num_rows > 0): ?>
                <div class="testimonials-grid">
                    <?php while($testimonial = $testimonials->fetch_assoc()): ?>
                        <div class="testimonial-card-large">
                            <div class="testimonial-rating">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star <?php echo $i <= $testimonial['rating'] ? 'active' : ''; ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <p class="testimonial-text">"<?php echo htmlspecialchars($testimonial['review']); ?>"</p>
                            <div class="testimonial-author">
                                <?php if($testimonial['photo']): ?>
                                    <img src="<?php echo htmlspecialchars($testimonial['photo']); ?>" 
                                         alt="<?php echo htmlspecialchars($testimonial['customer_name']); ?>"
                                         onerror="this.style.display='none'">
                                <?php else: ?>
                                    <div class="author-placeholder">
                                        <i class="fas fa-user"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="author-info">
                                    <h4><?php echo htmlspecialchars($testimonial['customer_name']); ?></h4>
                                    <p class="testimonial-date"><?php echo date('F Y', strtotime($testimonial['created_at'])); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="no-testimonials">
                    <i class="fas fa-comments"></i>
                    <h3>No testimonials yet</h3>
                    <p>Be the first to share your experience with us!</p>
                </div>
            <?php endif; ?>

            <div class="testimonial-cta">
                <h2>Share Your Experience</h2>
                <p>Have you purchased a car from us? We'd love to hear about your experience!</p>
                <a href="contact.php" class="btn btn-primary">Contact Us</a>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>
<?php $conn->close(); ?>

