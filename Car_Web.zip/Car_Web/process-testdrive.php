<?php
require_once 'config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $car_id = $_POST['car_id'] ?? null;
    $car_model = $_POST['car_model'] ?? '';
    $message = $_POST['message'] ?? '';
    $preferred_date = $_POST['preferred_date'] ?? '';
    $preferred_time = $_POST['preferred_time'] ?? '';

    if (empty($name) || empty($phone) || empty($email) || empty($preferred_date) || empty($preferred_time)) {
        header('Location: contact.php?status=error&message=' . urlencode('Please fill in all required fields.'));
        exit();
    }

    $conn = getDBConnection();
    
    // Insert as booking with test drive type
    $stmt = $conn->prepare("INSERT INTO bookings (name, phone, email, car_id, car_model, message, preferred_date, preferred_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssissss", $name, $phone, $email, $car_id, $car_model, $message, $preferred_date, $preferred_time);
    
    if ($stmt->execute()) {
        header('Location: index.php?status=success&message=' . urlencode('Test drive request submitted successfully! We will contact you to confirm the appointment.'));
    } else {
        header('Location: contact.php?status=error&message=' . urlencode('Error submitting test drive request. Please try again.'));
    }
    
    $stmt->close();
    $conn->close();
} else {
    header('Location: index.php');
}
exit();

