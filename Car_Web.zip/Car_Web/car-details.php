<?php
require_once 'config/config.php';
$conn = getDBConnection();

$car_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$car = $conn->query("SELECT * FROM cars WHERE id = $car_id")->fetch_assoc();

if (!$car) {
    header('Location: cars.php');
    exit();
}

// Get car images
$images = [];
if ($car['images']) {
    $images = json_decode($car['images'], true);
}
if ($car['image']) {
    array_unshift($images, $car['image']);
}
if (empty($images)) {
    $images = ['https://via.placeholder.com/800x600?text=Car+Image'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($car['name']); ?> - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section class="car-details-page">
        <div class="container">
            <div class="breadcrumb">
                <a href="index.php">Home</a> / <a href="cars.php">Cars</a> / <span><?php echo htmlspecialchars($car['name']); ?></span>
            </div>

            <div class="car-details-content">
                <!-- Car Images -->
                <div class="car-images-section">
                    <div class="main-image">
                        <img id="mainCarImage" src="<?php echo htmlspecialchars($images[0]); ?>" alt="<?php echo htmlspecialchars($car['name']); ?>">
                    </div>
                    <div class="image-thumbnails">
                        <?php foreach($images as $index => $img): ?>
                            <img src="<?php echo htmlspecialchars($img); ?>" 
                                 alt="Car Image <?php echo $index + 1; ?>"
                                 onclick="changeMainImage(this.src)"
                                 class="<?php echo $index === 0 ? 'active' : ''; ?>">
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Car Info -->
                <div class="car-info-section">
                    <h1><?php echo htmlspecialchars($car['name']); ?></h1>
                    <p class="car-subtitle"><?php echo htmlspecialchars($car['model']); ?> - <?php echo $car['year']; ?></p>
                    
                    <div class="car-price-section">
                        <div class="price-main">₹<?php echo number_format($car['price'], 2); ?></div>
                        <?php if ($car['on_road_price']): ?>
                            <div class="price-onroad">On-Road Price: ₹<?php echo number_format($car['on_road_price'], 2); ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="car-specs-grid">
                        <div class="spec-item">
                            <i class="fas fa-gas-pump"></i>
                            <div>
                                <strong>Fuel Type</strong>
                                <span><?php echo htmlspecialchars($car['fuel_type']); ?></span>
                            </div>
                        </div>
                        <div class="spec-item">
                            <i class="fas fa-cog"></i>
                            <div>
                                <strong>Transmission</strong>
                                <span><?php echo htmlspecialchars($car['transmission']); ?></span>
                            </div>
                        </div>
                        <div class="spec-item">
                            <i class="fas fa-tachometer-alt"></i>
                            <div>
                                <strong>Mileage</strong>
                                <span><?php echo htmlspecialchars($car['mileage']); ?></span>
                            </div>
                        </div>
                        <div class="spec-item">
                            <i class="fas fa-engine"></i>
                            <div>
                                <strong>Engine</strong>
                                <span><?php echo htmlspecialchars($car['engine_capacity']); ?></span>
                            </div>
                        </div>
                        <div class="spec-item">
                            <i class="fas fa-calendar"></i>
                            <div>
                                <strong>Year</strong>
                                <span><?php echo $car['year']; ?></span>
                            </div>
                        </div>
                        <div class="spec-item">
                            <i class="fas fa-check-circle"></i>
                            <div>
                                <strong>Status</strong>
                                <span><?php echo ucfirst($car['status']); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="action-buttons">
                        <button class="btn btn-primary btn-large" onclick="openBookingModal()">
                            <i class="fas fa-calendar-check"></i> Book Now
                        </button>
                        <button class="btn btn-secondary btn-large" onclick="openTestDriveModal()">
                            <i class="fas fa-car-side"></i> Request Test Drive
                        </button>
                        <button class="btn btn-outline btn-large" onclick="openEnquiryModal()">
                            <i class="fas fa-envelope"></i> Enquire Now
                        </button>
                    </div>
                </div>
            </div>

            <!-- Description & Features -->
            <div class="car-details-tabs">
                <div class="tabs">
                    <button class="tab-btn active" onclick="showTab('description')">Description</button>
                    <button class="tab-btn" onclick="showTab('features')">Features</button>
                    <button class="tab-btn" onclick="showTab('specifications')">Specifications</button>
                    <button class="tab-btn" onclick="showTab('emi')">EMI Calculator</button>
                </div>

                <div class="tab-content active" id="description">
                    <h3>Description</h3>
                    <p><?php echo nl2br(htmlspecialchars($car['description'] ?: 'No description available.')); ?></p>
                </div>

                <div class="tab-content" id="features">
                    <h3>Key Features</h3>
                    <?php if ($car['features']): ?>
                        <ul class="features-list">
                            <?php 
                            $features = explode("\n", $car['features']);
                            foreach($features as $feature): 
                                if(trim($feature)):
                            ?>
                                <li><i class="fas fa-check"></i> <?php echo htmlspecialchars(trim($feature)); ?></li>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </ul>
                    <?php else: ?>
                        <p>No features listed.</p>
                    <?php endif; ?>
                </div>

                <div class="tab-content" id="specifications">
                    <h3>Technical Specifications</h3>
                    <?php if ($car['specifications']): ?>
                        <div class="specifications-table">
                            <?php 
                            $specs = explode("\n", $car['specifications']);
                            foreach($specs as $spec): 
                                if(trim($spec)):
                                    $parts = explode(':', $spec, 2);
                                    if(count($parts) == 2):
                            ?>
                                <div class="spec-row">
                                    <span class="spec-label"><?php echo htmlspecialchars(trim($parts[0])); ?>:</span>
                                    <span class="spec-value"><?php echo htmlspecialchars(trim($parts[1])); ?></span>
                                </div>
                            <?php 
                                    endif;
                                endif;
                            endforeach; 
                            ?>
                        </div>
                    <?php else: ?>
                        <p>No specifications available.</p>
                    <?php endif; ?>
                </div>

                <div class="tab-content" id="emi">
                    <h3>EMI Calculator</h3>
                    <div class="emi-calculator">
                        <div class="calculator-inputs">
                            <div class="input-group">
                                <label>Loan Amount (₹)</label>
                                <input type="number" id="loanAmount" value="<?php echo $car['price']; ?>" oninput="calculateEMI()">
                            </div>
                            <div class="input-group">
                                <label>Interest Rate (% per annum)</label>
                                <input type="number" id="interestRate" value="8.5" step="0.1" oninput="calculateEMI()">
                            </div>
                            <div class="input-group">
                                <label>Loan Tenure (Years)</label>
                                <input type="number" id="loanTenure" value="5" min="1" max="7" oninput="calculateEMI()">
                            </div>
                        </div>
                        <div class="emi-result">
                            <div class="emi-amount">
                                <span>Monthly EMI</span>
                                <strong id="emiAmount">₹0</strong>
                            </div>
                            <div class="emi-details">
                                <div>
                                    <span>Total Amount</span>
                                    <span id="totalAmount">₹0</span>
                                </div>
                                <div>
                                    <span>Total Interest</span>
                                    <span id="totalInterest">₹0</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Booking Modal -->
    <div id="bookingModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('bookingModal')">&times;</span>
            <h2>Book This Car</h2>
            <form action="process-booking.php" method="POST">
                <input type="hidden" name="car_id" value="<?php echo $car['id']; ?>">
                <input type="hidden" name="car_model" value="<?php echo htmlspecialchars($car['name'] . ' ' . $car['model']); ?>">
                <div class="form-group">
                    <label>Name *</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label>Phone *</label>
                    <input type="tel" name="phone" required>
                </div>
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Preferred Date</label>
                    <input type="date" name="preferred_date">
                </div>
                <div class="form-group">
                    <label>Preferred Time</label>
                    <input type="time" name="preferred_time">
                </div>
                <div class="form-group">
                    <label>Message</label>
                    <textarea name="message" rows="4"></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Submit Booking</button>
            </form>
        </div>
    </div>

    <!-- Test Drive Modal -->
    <div id="testDriveModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('testDriveModal')">&times;</span>
            <h2>Request Test Drive</h2>
            <form action="process-testdrive.php" method="POST">
                <input type="hidden" name="car_id" value="<?php echo $car['id']; ?>">
                <input type="hidden" name="car_model" value="<?php echo htmlspecialchars($car['name'] . ' ' . $car['model']); ?>">
                <div class="form-group">
                    <label>Name *</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label>Phone *</label>
                    <input type="tel" name="phone" required>
                </div>
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Preferred Date *</label>
                    <input type="date" name="preferred_date" required>
                </div>
                <div class="form-group">
                    <label>Preferred Time *</label>
                    <input type="time" name="preferred_time" required>
                </div>
                <div class="form-group">
                    <label>Message</label>
                    <textarea name="message" rows="4" placeholder="Any specific requirements or questions?"></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Request Test Drive</button>
            </form>
        </div>
    </div>

    <!-- Enquiry Modal -->
    <div id="enquiryModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('enquiryModal')">&times;</span>
            <h2>Enquire About This Car</h2>
            <form action="process-enquiry.php" method="POST">
                <input type="hidden" name="car_id" value="<?php echo $car['id']; ?>">
                <div class="form-group">
                    <label>Name *</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label>Phone *</label>
                    <input type="tel" name="phone" required>
                </div>
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label>Subject</label>
                    <input type="text" name="subject" value="Enquiry about <?php echo htmlspecialchars($car['name']); ?>">
                </div>
                <div class="form-group">
                    <label>Message *</label>
                    <textarea name="message" rows="4" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Submit Enquiry</button>
            </form>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
    <script>
        function changeMainImage(src) {
            document.getElementById('mainCarImage').src = src;
            document.querySelectorAll('.image-thumbnails img').forEach(img => {
                img.classList.remove('active');
                if (img.src === src) img.classList.add('active');
            });
        }

        function showTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }

        function calculateEMI() {
            const principal = parseFloat(document.getElementById('loanAmount').value) || 0;
            const rate = parseFloat(document.getElementById('interestRate').value) || 0;
            const tenure = parseFloat(document.getElementById('loanTenure').value) || 0;
            
            if (principal > 0 && rate > 0 && tenure > 0) {
                const monthlyRate = rate / 12 / 100;
                const months = tenure * 12;
                const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
                const totalAmount = emi * months;
                const totalInterest = totalAmount - principal;
                
                document.getElementById('emiAmount').textContent = '₹' + emi.toFixed(2);
                document.getElementById('totalAmount').textContent = '₹' + totalAmount.toFixed(2);
                document.getElementById('totalInterest').textContent = '₹' + totalInterest.toFixed(2);
            }
        }

        function openBookingModal() {
            document.getElementById('bookingModal').style.display = 'block';
        }

        function openTestDriveModal() {
            document.getElementById('testDriveModal').style.display = 'block';
        }

        function openEnquiryModal() {
            document.getElementById('enquiryModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }

        // Calculate EMI on page load
        calculateEMI();
    </script>
</body>
</html>
<?php $conn->close(); ?>

