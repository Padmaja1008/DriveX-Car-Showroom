<?php
require_once 'config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-header">
        <div class="container">
            <h1>Our Services</h1>
            <p>Comprehensive automotive solutions for all your needs</p>
        </div>
    </section>

    <section class="services-content">
        <div class="container">
            <div class="service-card" id="sales">
                <div class="service-icon">
                    <i class="fas fa-car"></i>
                </div>
                <div class="service-content">
                    <h2>Car Sales</h2>
                    <h3>New & Used Vehicles</h3>
                    <p>We offer an extensive collection of both new and pre-owned vehicles from leading manufacturers. Whether you're looking for a brand new luxury sedan or a reliable used car, we have options to suit every budget and preference.</p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Wide selection of new cars from top brands</li>
                        <li><i class="fas fa-check"></i> Certified pre-owned vehicles with warranty</li>
                        <li><i class="fas fa-check"></i> Transparent pricing with no hidden charges</li>
                        <li><i class="fas fa-check"></i> Vehicle history reports for used cars</li>
                        <li><i class="fas fa-check"></i> Test drive facility for all vehicles</li>
                    </ul>
                    <a href="cars.php" class="btn btn-primary">Browse Cars</a>
                </div>
            </div>

            <div class="service-card" id="financing">
                <div class="service-icon">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="service-content">
                    <h2>Car Financing & Loan Assistance</h2>
                    <h3>Easy EMI Options</h3>
                    <p>Make your dream car affordable with our flexible financing solutions. We partner with leading banks and financial institutions to offer you the best loan rates and easy EMI options.</p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Quick loan approval process</li>
                        <li><i class="fas fa-check"></i> Competitive interest rates</li>
                        <li><i class="fas fa-check"></i> Flexible repayment tenure (1-7 years)</li>
                        <li><i class="fas fa-check"></i> Minimal documentation required</li>
                        <li><i class="fas fa-check"></i> Expert financial advisors to guide you</li>
                        <li><i class="fas fa-check"></i> EMI calculator for easy planning</li>
                    </ul>
                    <a href="contact.php" class="btn btn-primary">Get Financing</a>
                </div>
            </div>

            <div class="service-card" id="insurance">
                <div class="service-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <div class="service-content">
                    <h2>Car Insurance</h2>
                    <h3>Comprehensive Coverage</h3>
                    <p>Protect your investment with our comprehensive car insurance solutions. We offer policies from leading insurance companies with the best coverage at competitive rates.</p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Third-party and comprehensive insurance</li>
                        <li><i class="fas fa-check"></i> Quick claim processing</li>
                        <li><i class="fas fa-check"></i> Cashless claim facility</li>
                        <li><i class="fas fa-check"></i> Renewal reminders and assistance</li>
                        <li><i class="fas fa-check"></i> Add-on covers available</li>
                        <li><i class="fas fa-check"></i> Expert guidance on policy selection</li>
                    </ul>
                    <a href="contact.php" class="btn btn-primary">Get Insurance Quote</a>
                </div>
            </div>

            <div class="service-card" id="servicing">
                <div class="service-icon">
                    <i class="fas fa-tools"></i>
                </div>
                <div class="service-content">
                    <h2>Car Servicing & Maintenance</h2>
                    <h3>Expert Care for Your Vehicle</h3>
                    <p>Keep your car in perfect condition with our professional servicing and maintenance services. Our state-of-the-art service center is equipped with the latest tools and staffed by certified technicians.</p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Regular maintenance and servicing</li>
                        <li><i class="fas fa-check"></i> Engine diagnostics and repair</li>
                        <li><i class="fas fa-check"></i> Oil change and fluid replacement</li>
                        <li><i class="fas fa-check"></i> Brake and tire services</li>
                        <li><i class="fas fa-check"></i> AC service and repair</li>
                        <li><i class="fas fa-check"></i> Bodywork and paint services</li>
                        <li><i class="fas fa-check"></i> Genuine parts and accessories</li>
                    </ul>
                    <a href="contact.php" class="btn btn-primary">Book Service</a>
                </div>
            </div>

            <div class="service-card" id="accessories">
                <div class="service-icon">
                    <i class="fas fa-puzzle-piece"></i>
                </div>
                <div class="service-content">
                    <h2>Car Accessories</h2>
                    <h3>Enhance Your Driving Experience</h3>
                    <p>Personalize and enhance your vehicle with our wide range of genuine and premium accessories. From interior upgrades to exterior modifications, we have everything you need.</p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> Interior accessories (seat covers, floor mats, etc.)</li>
                        <li><i class="fas fa-check"></i> Exterior accessories (body kits, spoilers, etc.)</li>
                        <li><i class="fas fa-check"></i> Electronics (GPS, dash cams, sound systems)</li>
                        <li><i class="fas fa-check"></i> Safety accessories (parking sensors, reverse cameras)</li>
                        <li><i class="fas fa-check"></i> Genuine OEM parts</li>
                        <li><i class="fas fa-check"></i> Professional installation service</li>
                    </ul>
                    <a href="contact.php" class="btn btn-primary">View Accessories</a>
                </div>
            </div>

            <div class="service-card" id="roadside">
                <div class="service-icon">
                    <i class="fas fa-road"></i>
                </div>
                <div class="service-content">
                    <h2>Roadside Assistance</h2>
                    <h3>24/7 Support When You Need It</h3>
                    <p>Never get stranded on the road. Our 24/7 roadside assistance service ensures help is just a call away, whether you need a battery jump, tire change, fuel delivery, or towing service.</p>
                    <ul class="service-features">
                        <li><i class="fas fa-check"></i> 24/7 emergency helpline</li>
                        <li><i class="fas fa-check"></i> Battery jump-start service</li>
                        <li><i class="fas fa-check"></i> Flat tire replacement</li>
                        <li><i class="fas fa-check"></i> Fuel delivery service</li>
                        <li><i class="fas fa-check"></i> Lockout assistance</li>
                        <li><i class="fas fa-check"></i> Towing service to nearest service center</li>
                        <li><i class="fas fa-check"></i> Minor on-site repairs</li>
                    </ul>
                    <a href="contact.php" class="btn btn-primary">Get Roadside Assistance</a>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <h2>Ready to Get Started?</h2>
            <p>Contact us today to learn more about our services or to schedule an appointment.</p>
            <div class="cta-buttons">
                <a href="contact.php" class="btn btn-primary btn-large">Contact Us</a>
                <a href="cars.php" class="btn btn-secondary btn-large">Browse Cars</a>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>

