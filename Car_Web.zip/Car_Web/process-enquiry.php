<?php
require_once 'config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';

    if (empty($name) || empty($phone) || empty($email) || empty($message)) {
        header('Location: contact.php?status=error&message=' . urlencode('Please fill in all required fields.'));
        exit();
    }

    $conn = getDBConnection();
    
    $stmt = $conn->prepare("INSERT INTO enquiries (name, phone, email, subject, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $phone, $email, $subject, $message);
    
    if ($stmt->execute()) {
        header('Location: contact.php?status=success&message=' . urlencode('Enquiry submitted successfully! We will get back to you soon.'));
    } else {
        header('Location: contact.php?status=error&message=' . urlencode('Error submitting enquiry. Please try again.'));
    }
    
    $stmt->close();
    $conn->close();
} else {
    header('Location: contact.php');
}
exit();

