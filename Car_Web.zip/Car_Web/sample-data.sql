-- Sample Data for Car Showroom Website
-- Run this SQL script to add sample cars and testimonials

USE car_showroom;

-- Insert Sample Cars
INSERT INTO cars (name, model, year, price, fuel_type, transmission, mileage, engine_capacity, description, features, specifications, on_road_price, image, images, status) VALUES
('Toyota Camry', 'XLE', 2024, 3500000.00, 'Hybrid', 'Automatic', '23.27 km/l', '2.5L', 
'The Toyota Camry XLE is a premium sedan that combines elegance with efficiency. Perfect for families and professionals who want comfort and reliability.',
'LED Headlights\nSunroof\nLeather Seats\nNavigation System\nApple CarPlay\nAndroid Auto\nBlind Spot Monitor\nRear Camera\nPush Button Start\nDual Zone Climate Control',
'Length: 4885 mm\nWidth: 1840 mm\nHeight: 1445 mm\nWheelbase: 2825 mm\nGround Clearance: 160 mm\nFuel Tank: 60 L\nBoot Space: 524 L\nSeating Capacity: 5',
3800000.00,
'https://via.placeholder.com/800x600?text=Toyota+Camry',
'["https://via.placeholder.com/800x600?text=Toyota+Camry+1", "https://via.placeholder.com/800x600?text=Toyota+Camry+2"]',
'available'),

('Honda Civic', 'VX', 2024, 2200000.00, 'Petrol', 'Automatic', '17.8 km/l', '1.8L',
'The Honda Civic VX is a sporty and reliable sedan that offers excellent fuel economy and modern features. Ideal for daily commuting.',
'LED Daytime Running Lights\nTouchscreen Infotainment\nReverse Camera\nPush Button Start\nCruise Control\nSteering Mounted Controls\nAutomatic Climate Control\nKeyless Entry',
'Length: 4649 mm\nWidth: 1799 mm\nHeight: 1416 mm\nWheelbase: 2700 mm\nGround Clearance: 165 mm\nFuel Tank: 47 L\nBoot Space: 430 L\nSeating Capacity: 5',
2400000.00,
'https://via.placeholder.com/800x600?text=Honda+Civic',
'["https://via.placeholder.com/800x600?text=Honda+Civic+1", "https://via.placeholder.com/800x600?text=Honda+Civic+2"]',
'available'),

('Ford Mustang', 'GT', 2024, 7500000.00, 'Petrol', 'Automatic', '12.4 km/l', '5.0L V8',
'The Ford Mustang GT is a legendary sports car with a powerful V8 engine. Experience the thrill of American muscle.',
'LED Headlights\nRecaro Seats\n12-inch Digital Cluster\nSYNC 4 Infotainment\nB&O Sound System\nTrack Apps\nLine Lock\nLaunch Control\nMagneRide Suspension\nActive Exhaust',
'Length: 4789 mm\nWidth: 1916 mm\nHeight: 1381 mm\nWheelbase: 2720 mm\nGround Clearance: 130 mm\nFuel Tank: 61 L\nBoot Space: 382 L\nSeating Capacity: 4',
8200000.00,
'https://via.placeholder.com/800x600?text=Ford+Mustang',
'["https://via.placeholder.com/800x600?text=Ford+Mustang+1", "https://via.placeholder.com/800x600?text=Ford+Mustang+2"]',
'available'),

('Tesla Model 3', 'Long Range', 2024, 5500000.00, 'Electric', 'Automatic', 'N/A (Electric)', 'Electric Motor',
'The Tesla Model 3 Long Range is a premium electric sedan with impressive range and cutting-edge technology. Zero emissions, maximum performance.',
'Autopilot\n15-inch Touchscreen\nPremium Audio\nGlass Roof\nHeated Seats\nWireless Charging\nSupercharger Access\nOver-the-Air Updates\nSentry Mode\nDog Mode',
'Length: 4694 mm\nWidth: 1850 mm\nHeight: 1443 mm\nWheelbase: 2875 mm\nGround Clearance: 140 mm\nBattery: 75 kWh\nRange: 602 km\nCharging Time: 8-10 hours (AC)\nSeating Capacity: 5',
5800000.00,
'https://via.placeholder.com/800x600?text=Tesla+Model+3',
'["https://via.placeholder.com/800x600?text=Tesla+Model+3+1", "https://via.placeholder.com/800x600?text=Tesla+Model+3+2"]',
'available'),

('BMW 3 Series', '330i', 2024, 4500000.00, 'Petrol', 'Automatic', '15.2 km/l', '2.0L Turbo',
'The BMW 3 Series 330i combines luxury, performance, and technology. Experience the ultimate driving machine.',
'LED Headlights\nPanoramic Sunroof\nLeather Upholstery\niDrive 7.0\nHarman Kardon Audio\nWireless Charging\nParking Assistant\nAdaptive Cruise Control\nHeated Seats\nAmbient Lighting',
'Length: 4709 mm\nWidth: 1827 mm\nHeight: 1442 mm\nWheelbase: 2851 mm\nGround Clearance: 140 mm\nFuel Tank: 59 L\nBoot Space: 480 L\nSeating Capacity: 5',
4900000.00,
'https://via.placeholder.com/800x600?text=BMW+3+Series',
'["https://via.placeholder.com/800x600?text=BMW+3+Series+1", "https://via.placeholder.com/800x600?text=BMW+3+Series+2"]',
'available'),

('Mercedes-Benz C-Class', 'C200', 2024, 4200000.00, 'Petrol', 'Automatic', '14.5 km/l', '1.5L Turbo',
'The Mercedes-Benz C-Class C200 offers luxury, comfort, and advanced technology in a compact executive sedan.',
'LED Headlights\nPanoramic Sunroof\nMBUX Infotainment\nBurmester Audio\nWireless Charging\n360° Camera\nParking Assist\nAdaptive Cruise Control\nAmbient Lighting\nKeyless Go',
'Length: 4751 mm\nWidth: 1820 mm\nHeight: 1438 mm\nWheelbase: 2840 mm\nGround Clearance: 135 mm\nFuel Tank: 66 L\nBoot Space: 455 L\nSeating Capacity: 5',
4600000.00,
'https://via.placeholder.com/800x600?text=Mercedes+C-Class',
'["https://via.placeholder.com/800x600?text=Mercedes+C-Class+1", "https://via.placeholder.com/800x600?text=Mercedes+C-Class+2"]',
'available'),

('Audi A4', 'Premium Plus', 2024, 4100000.00, 'Petrol', 'Automatic', '15.5 km/l', '2.0L TFSI',
'The Audi A4 Premium Plus is a sophisticated sedan that blends performance, luxury, and cutting-edge technology.',
'Matrix LED Headlights\nVirtual Cockpit\nMMI Touch\nBang & Olufsen Audio\nWireless Charging\n360° Camera\nPark Assist\nAdaptive Cruise Control\nPanoramic Sunroof\nQuattro AWD',
'Length: 4762 mm\nWidth: 1847 mm\nHeight: 1431 mm\nWheelbase: 2820 mm\nGround Clearance: 130 mm\nFuel Tank: 54 L\nBoot Space: 460 L\nSeating Capacity: 5',
4500000.00,
'https://via.placeholder.com/800x600?text=Audi+A4',
'["https://via.placeholder.com/800x600?text=Audi+A4+1", "https://via.placeholder.com/800x600?text=Audi+A4+2"]',
'available'),

('Hyundai Creta', 'SX', 2024, 1800000.00, 'Petrol', 'Automatic', '16.8 km/l', '1.5L',
'The Hyundai Creta SX is a feature-packed compact SUV perfect for urban adventures and family trips.',
'LED Headlights\nPanoramic Sunroof\n10.25-inch Touchscreen\nBose Audio\nWireless Charging\n360° Camera\nVentilated Seats\nCruise Control\nPush Button Start\nKeyless Entry',
'Length: 4300 mm\nWidth: 1790 mm\nHeight: 1635 mm\nWheelbase: 2610 mm\nGround Clearance: 190 mm\nFuel Tank: 50 L\nBoot Space: 433 L\nSeating Capacity: 5',
2000000.00,
'https://via.placeholder.com/800x600?text=Hyundai+Creta',
'["https://via.placeholder.com/800x600?text=Hyundai+Creta+1", "https://via.placeholder.com/800x600?text=Hyundai+Creta+2"]',
'available');

-- Insert Sample Testimonials
INSERT INTO testimonials (customer_name, rating, review, photo, status) VALUES
('Rajesh Kumar', 5, 'Excellent service and great collection of cars. The staff was very helpful and guided me through the entire process. Highly recommended!', NULL, 'active'),
('Priya Sharma', 5, 'Bought my dream car from this showroom. The entire experience was smooth and professional. The EMI options were also very flexible.', NULL, 'active'),
('Amit Patel', 4, 'Good showroom with a wide variety of cars. The test drive experience was great. The only thing that could be improved is the waiting time.', NULL, 'active'),
('Sneha Reddy', 5, 'Amazing customer service! The team helped me find the perfect car within my budget. The after-sales service is also excellent.', NULL, 'active'),
('Vikram Singh', 5, 'Best car dealership in the city. Transparent pricing, no hidden charges, and excellent financing options. Will definitely recommend to friends!', NULL, 'active'),
('Anjali Mehta', 4, 'Great experience overall. The car I purchased is perfect and the showroom staff was very knowledgeable. Happy with my purchase!', NULL, 'active');

