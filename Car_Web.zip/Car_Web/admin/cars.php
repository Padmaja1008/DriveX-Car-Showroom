<?php
require_once '../config/config.php';
requireAdminLogin();

$conn = getDBConnection();

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM cars WHERE id = $id");
    header('Location: cars.php?status=success&message=' . urlencode('Car deleted successfully'));
    exit();
}

$cars = $conn->query("SELECT * FROM cars ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Cars - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-header {
            background: #1d3557;
            color: #fff;
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        .admin-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: #fff;
            text-decoration: none;
            margin-left: 1rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        table th, table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background: #f1faee;
            font-weight: 600;
        }
        .car-image-small {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
        }
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="admin-nav">
                <h1><i class="fas fa-car"></i> Manage Cars</h1>
                <div>
                    <a href="index.php"><i class="fas fa-arrow-left"></i> Dashboard</a>
                    <a href="../index.php"><i class="fas fa-home"></i> View Site</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <h2>All Cars</h2>
            <a href="car-add.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add New Car</a>
        </div>

        <?php if (isset($_GET['status'])): ?>
            <div style="padding: 1rem; background: <?php echo $_GET['status'] == 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $_GET['status'] == 'success' ? '#155724' : '#721c24'; ?>; border-radius: 5px; margin-bottom: 1rem;">
                <?php echo htmlspecialchars($_GET['message'] ?? ''); ?>
            </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Model</th>
                    <th>Year</th>
                    <th>Price</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($cars->num_rows > 0): ?>
                    <?php while($car = $cars->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <img src="../<?php echo htmlspecialchars($car['image'] ?: 'assets/images/car-placeholder.jpg'); ?>" 
                                     alt="<?php echo htmlspecialchars($car['name']); ?>"
                                     class="car-image-small"
                                     onerror="this.src='https://via.placeholder.com/80x60?text=Car'">
                            </td>
                            <td><?php echo htmlspecialchars($car['name']); ?></td>
                            <td><?php echo htmlspecialchars($car['model']); ?></td>
                            <td><?php echo $car['year']; ?></td>
                            <td>₹<?php echo number_format($car['price'], 2); ?></td>
                            <td><span style="padding: 0.25rem 0.5rem; background: #f1faee; border-radius: 3px;"><?php echo ucfirst($car['status']); ?></span></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="car-edit.php?id=<?php echo $car['id']; ?>" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i> Edit</a>
                                    <a href="?delete=<?php echo $car['id']; ?>" 
                                       class="btn btn-primary btn-sm" 
                                       onclick="return confirm('Are you sure you want to delete this car?')"
                                       style="background: #e63946;"><i class="fas fa-trash"></i> Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="7" style="text-align: center; padding: 2rem;">No cars found. <a href="car-add.php">Add your first car</a></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php $conn->close(); ?>

