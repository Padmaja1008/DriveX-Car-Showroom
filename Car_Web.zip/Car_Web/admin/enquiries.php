<?php
require_once '../config/config.php';
requireAdminLogin();

$conn = getDBConnection();

// Handle status update
if (isset($_GET['update_status'])) {
    $id = (int)$_GET['id'];
    $status = $_GET['status'];
    $conn->query("UPDATE enquiries SET status = '$status' WHERE id = $id");
    header('Location: enquiries.php?status=success&message=' . urlencode('Enquiry status updated'));
    exit();
}

// Get single enquiry or all enquiries
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $enquiry = $conn->query("SELECT * FROM enquiries WHERE id = $id")->fetch_assoc();
    if (!$enquiry) {
        header('Location: enquiries.php');
        exit();
    }
    // Mark as read
    $conn->query("UPDATE enquiries SET status = 'read' WHERE id = $id AND status = 'new'");
} else {
    $enquiries = $conn->query("SELECT * FROM enquiries ORDER BY created_at DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Enquiries - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-header {
            background: #1d3557;
            color: #fff;
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        .admin-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: #fff;
            text-decoration: none;
            margin-left: 1rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        table th, table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background: #f1faee;
            font-weight: 600;
        }
        .enquiry-detail {
            background: #fff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .detail-row {
            display: grid;
            grid-template-columns: 200px 1fr;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }
        .new-badge {
            background: #e63946;
            color: #fff;
            padding: 0.25rem 0.5rem;
            border-radius: 3px;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="admin-nav">
                <h1><i class="fas fa-envelope"></i> Manage Enquiries</h1>
                <div>
                    <a href="index.php"><i class="fas fa-arrow-left"></i> Dashboard</a>
                    <a href="../index.php"><i class="fas fa-home"></i> View Site</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if (isset($_GET['status'])): ?>
            <div style="padding: 1rem; background: <?php echo $_GET['status'] == 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $_GET['status'] == 'success' ? '#155724' : '#721c24'; ?>; border-radius: 5px; margin-bottom: 1rem;">
                <?php echo htmlspecialchars($_GET['message'] ?? ''); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($enquiry)): ?>
            <div class="enquiry-detail">
                <h2>Enquiry Details <?php if($enquiry['status'] == 'new'): ?><span class="new-badge">NEW</span><?php endif; ?></h2>
                <div class="detail-row">
                    <strong>Name:</strong>
                    <span><?php echo htmlspecialchars($enquiry['name']); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Phone:</strong>
                    <span><?php echo htmlspecialchars($enquiry['phone']); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Email:</strong>
                    <span><?php echo htmlspecialchars($enquiry['email']); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Subject:</strong>
                    <span><?php echo htmlspecialchars($enquiry['subject'] ?: 'No subject'); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Message:</strong>
                    <span><?php echo nl2br(htmlspecialchars($enquiry['message'])); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Status:</strong>
                    <span>
                        <select onchange="updateStatus(<?php echo $enquiry['id']; ?>, this.value)">
                            <option value="new" <?php echo $enquiry['status'] == 'new' ? 'selected' : ''; ?>>New</option>
                            <option value="read" <?php echo $enquiry['status'] == 'read' ? 'selected' : ''; ?>>Read</option>
                            <option value="replied" <?php echo $enquiry['status'] == 'replied' ? 'selected' : ''; ?>>Replied</option>
                        </select>
                    </span>
                </div>
                <div class="detail-row">
                    <strong>Created At:</strong>
                    <span><?php echo date('F d, Y g:i A', strtotime($enquiry['created_at'])); ?></span>
                </div>
                <a href="enquiries.php" class="btn btn-primary">Back to All Enquiries</a>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Subject</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($enquiries->num_rows > 0): ?>
                        <?php while($enquiry = $enquiries->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $enquiry['id']; ?></td>
                                <td><?php echo htmlspecialchars($enquiry['name']); ?></td>
                                <td><?php echo htmlspecialchars($enquiry['subject'] ?: 'No subject'); ?></td>
                                <td><?php echo date('M d, Y', strtotime($enquiry['created_at'])); ?></td>
                                <td>
                                    <span style="padding: 0.25rem 0.5rem; background: <?php echo $enquiry['status'] == 'new' ? '#fee' : '#f1faee'; ?>; border-radius: 3px;">
                                        <?php echo ucfirst($enquiry['status']); ?>
                                    </span>
                                </td>
                                <td><a href="?id=<?php echo $enquiry['id']; ?>">View</a></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align: center; padding: 2rem;">No enquiries found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <script>
        function updateStatus(id, status) {
            if (confirm('Update enquiry status to ' + status + '?')) {
                window.location.href = '?update_status=1&id=' + id + '&status=' + status;
            }
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>

