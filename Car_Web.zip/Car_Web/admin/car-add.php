<?php
require_once '../config/config.php';
requireAdminLogin();

$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $model = $_POST['model'] ?? '';
    $year = (int)($_POST['year'] ?? 2024);
    $price = $_POST['price'] ?? 0;
    $fuel_type = $_POST['fuel_type'] ?? '';
    $transmission = $_POST['transmission'] ?? '';
    $mileage = $_POST['mileage'] ?? '';
    $engine_capacity = $_POST['engine_capacity'] ?? '';
    $description = $_POST['description'] ?? '';
    $features = $_POST['features'] ?? '';
    $specifications = $_POST['specifications'] ?? '';
    $on_road_price = $_POST['on_road_price'] ?? null;
    $status = $_POST['status'] ?? 'available';
    $image = $_POST['image'] ?? '';
    $images = $_POST['images'] ?? '[]';

    $stmt = $conn->prepare("INSERT INTO cars (name, model, year, price, fuel_type, transmission, mileage, engine_capacity, description, features, specifications, on_road_price, image, images, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssidsssssssdsss", $name, $model, $year, $price, $fuel_type, $transmission, $mileage, $engine_capacity, $description, $features, $specifications, $on_road_price, $image, $images, $status);
    
    if ($stmt->execute()) {
        header('Location: cars.php?status=success&message=' . urlencode('Car added successfully'));
        exit();
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Car - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-header {
            background: #1d3557;
            color: #fff;
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        .admin-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: #fff;
            text-decoration: none;
            margin-left: 1rem;
        }
        .form-container {
            background: #fff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="admin-nav">
                <h1><i class="fas fa-plus"></i> Add New Car</h1>
                <div>
                    <a href="cars.php"><i class="fas fa-arrow-left"></i> Back to Cars</a>
                    <a href="index.php"><i class="fas fa-home"></i> Dashboard</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="form-container">
            <form method="POST" action="">
                <div class="form-row">
                    <div class="form-group">
                        <label>Car Name *</label>
                        <input type="text" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Model *</label>
                        <input type="text" name="model" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Year *</label>
                        <input type="number" name="year" min="2000" max="2030" value="2024" required>
                    </div>
                    <div class="form-group">
                        <label>Price (₹) *</label>
                        <input type="number" name="price" step="0.01" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>On-Road Price (₹)</label>
                        <input type="number" name="on_road_price" step="0.01">
                    </div>
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" required>
                            <option value="available">Available</option>
                            <option value="sold">Sold</option>
                            <option value="reserved">Reserved</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Fuel Type *</label>
                        <select name="fuel_type" required>
                            <option value="Petrol">Petrol</option>
                            <option value="Diesel">Diesel</option>
                            <option value="Electric">Electric</option>
                            <option value="Hybrid">Hybrid</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Transmission *</label>
                        <select name="transmission" required>
                            <option value="Automatic">Automatic</option>
                            <option value="Manual">Manual</option>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Mileage *</label>
                        <input type="text" name="mileage" placeholder="e.g., 15 km/l" required>
                    </div>
                    <div class="form-group">
                        <label>Engine Capacity *</label>
                        <input type="text" name="engine_capacity" placeholder="e.g., 1.5L" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Main Image URL</label>
                    <input type="url" name="image" placeholder="https://example.com/image.jpg">
                </div>

                <div class="form-group">
                    <label>Additional Images (JSON array)</label>
                    <textarea name="images" rows="3" placeholder='["https://example.com/img1.jpg", "https://example.com/img2.jpg"]'>[]</textarea>
                    <small>Enter as JSON array of image URLs</small>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="4"></textarea>
                </div>

                <div class="form-group">
                    <label>Features (one per line)</label>
                    <textarea name="features" rows="6" placeholder="Air Conditioning&#10;Power Steering&#10;ABS Brakes"></textarea>
                </div>

                <div class="form-group">
                    <label>Specifications (Format: Label: Value, one per line)</label>
                    <textarea name="specifications" rows="6" placeholder="Length: 4500 mm&#10;Width: 1800 mm&#10;Height: 1500 mm"></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-large">Add Car</button>
            </form>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>

