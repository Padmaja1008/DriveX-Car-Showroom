<?php
require_once '../config/config.php';
requireAdminLogin();

$conn = getDBConnection();

// Get statistics
$totalCars = $conn->query("SELECT COUNT(*) as count FROM cars")->fetch_assoc()['count'];
$availableCars = $conn->query("SELECT COUNT(*) as count FROM cars WHERE status = 'available'")->fetch_assoc()['count'];
$totalBookings = $conn->query("SELECT COUNT(*) as count FROM bookings")->fetch_assoc()['count'];
$pendingBookings = $conn->query("SELECT COUNT(*) as count FROM bookings WHERE status = 'pending'")->fetch_assoc()['count'];
$totalEnquiries = $conn->query("SELECT COUNT(*) as count FROM enquiries")->fetch_assoc()['count'];
$newEnquiries = $conn->query("SELECT COUNT(*) as count FROM enquiries WHERE status = 'new'")->fetch_assoc()['count'];

// Recent bookings
$recentBookings = $conn->query("SELECT * FROM bookings ORDER BY created_at DESC LIMIT 5");

// Recent enquiries
$recentEnquiries = $conn->query("SELECT * FROM enquiries ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-header {
            background: #1d3557;
            color: #fff;
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        .admin-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: #fff;
            text-decoration: none;
            margin-left: 1rem;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: #fff;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }
        .stat-card .number {
            font-size: 2rem;
            font-weight: bold;
            color: #e63946;
        }
        .admin-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }
        .admin-section {
            background: #fff;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .admin-section h2 {
            margin-bottom: 1rem;
            color: #1d3557;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background: #f1faee;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="admin-nav">
                <h1><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h1>
                <div>
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    <a href="../index.php"><i class="fas fa-home"></i> View Site</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Cars</h3>
                <div class="number"><?php echo $totalCars; ?></div>
            </div>
            <div class="stat-card">
                <h3>Available Cars</h3>
                <div class="number"><?php echo $availableCars; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Bookings</h3>
                <div class="number"><?php echo $totalBookings; ?></div>
            </div>
            <div class="stat-card">
                <h3>Pending Bookings</h3>
                <div class="number"><?php echo $pendingBookings; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Enquiries</h3>
                <div class="number"><?php echo $totalEnquiries; ?></div>
            </div>
            <div class="stat-card">
                <h3>New Enquiries</h3>
                <div class="number"><?php echo $newEnquiries; ?></div>
            </div>
        </div>

        <div class="admin-content">
            <div class="admin-section">
                <h2>Recent Bookings</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Car Model</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recentBookings->num_rows > 0): ?>
                            <?php while($booking = $recentBookings->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($booking['name']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['car_model']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($booking['created_at'])); ?></td>
                                    <td><span style="padding: 0.25rem 0.5rem; background: #f1faee; border-radius: 3px;"><?php echo ucfirst($booking['status']); ?></span></td>
                                    <td><a href="bookings.php?id=<?php echo $booking['id']; ?>">View</a></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5">No bookings yet</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <a href="bookings.php" class="btn btn-primary" style="margin-top: 1rem;">View All Bookings</a>
            </div>

            <div class="admin-section">
                <h2>Recent Enquiries</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Subject</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recentEnquiries->num_rows > 0): ?>
                            <?php while($enquiry = $recentEnquiries->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($enquiry['name']); ?></td>
                                    <td><?php echo htmlspecialchars($enquiry['subject'] ?: 'No subject'); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($enquiry['created_at'])); ?></td>
                                    <td><span style="padding: 0.25rem 0.5rem; background: <?php echo $enquiry['status'] == 'new' ? '#fee' : '#f1faee'; ?>; border-radius: 3px;"><?php echo ucfirst($enquiry['status']); ?></span></td>
                                    <td><a href="enquiries.php?id=<?php echo $enquiry['id']; ?>">View</a></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5">No enquiries yet</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <a href="enquiries.php" class="btn btn-primary" style="margin-top: 1rem;">View All Enquiries</a>
            </div>
        </div>

        <div style="margin-top: 2rem;">
            <h2>Quick Actions</h2>
            <div style="display: flex; gap: 1rem; flex-wrap: wrap; margin-top: 1rem;">
                <a href="cars.php" class="btn btn-primary"><i class="fas fa-car"></i> Manage Cars</a>
                <a href="bookings.php" class="btn btn-secondary"><i class="fas fa-calendar-check"></i> Manage Bookings</a>
                <a href="enquiries.php" class="btn btn-secondary"><i class="fas fa-envelope"></i> Manage Enquiries</a>
                <a href="testimonials.php" class="btn btn-outline"><i class="fas fa-star"></i> Manage Testimonials</a>
            </div>
        </div>
    </div>
</body>
</html>
<?php $conn->close(); ?>

