<?php
require_once '../config/config.php';
requireAdminLogin();

$conn = getDBConnection();

// Handle status update
if (isset($_GET['update_status'])) {
    $id = (int)$_GET['id'];
    $status = $_GET['status'];
    $conn->query("UPDATE bookings SET status = '$status' WHERE id = $id");
    header('Location: bookings.php?status=success&message=' . urlencode('Booking status updated'));
    exit();
}

// Get single booking or all bookings
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $booking = $conn->query("SELECT * FROM bookings WHERE id = $id")->fetch_assoc();
    if (!$booking) {
        header('Location: bookings.php');
        exit();
    }
} else {
    $bookings = $conn->query("SELECT * FROM bookings ORDER BY created_at DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-header {
            background: #1d3557;
            color: #fff;
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        .admin-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: #fff;
            text-decoration: none;
            margin-left: 1rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        table th, table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background: #f1faee;
            font-weight: 600;
        }
        .booking-detail {
            background: #fff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .detail-row {
            display: grid;
            grid-template-columns: 200px 1fr;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #eee;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="admin-nav">
                <h1><i class="fas fa-calendar-check"></i> Manage Bookings</h1>
                <div>
                    <a href="index.php"><i class="fas fa-arrow-left"></i> Dashboard</a>
                    <a href="../index.php"><i class="fas fa-home"></i> View Site</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if (isset($_GET['status'])): ?>
            <div style="padding: 1rem; background: <?php echo $_GET['status'] == 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $_GET['status'] == 'success' ? '#155724' : '#721c24'; ?>; border-radius: 5px; margin-bottom: 1rem;">
                <?php echo htmlspecialchars($_GET['message'] ?? ''); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($booking)): ?>
            <div class="booking-detail">
                <h2>Booking Details</h2>
                <div class="detail-row">
                    <strong>Name:</strong>
                    <span><?php echo htmlspecialchars($booking['name']); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Phone:</strong>
                    <span><?php echo htmlspecialchars($booking['phone']); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Email:</strong>
                    <span><?php echo htmlspecialchars($booking['email']); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Car Model:</strong>
                    <span><?php echo htmlspecialchars($booking['car_model']); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Preferred Date:</strong>
                    <span><?php echo $booking['preferred_date'] ? date('F d, Y', strtotime($booking['preferred_date'])) : 'Not specified'; ?></span>
                </div>
                <div class="detail-row">
                    <strong>Preferred Time:</strong>
                    <span><?php echo $booking['preferred_time'] ? date('g:i A', strtotime($booking['preferred_time'])) : 'Not specified'; ?></span>
                </div>
                <div class="detail-row">
                    <strong>Message:</strong>
                    <span><?php echo nl2br(htmlspecialchars($booking['message'] ?: 'No message')); ?></span>
                </div>
                <div class="detail-row">
                    <strong>Status:</strong>
                    <span>
                        <select onchange="updateStatus(<?php echo $booking['id']; ?>, this.value)">
                            <option value="pending" <?php echo $booking['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="confirmed" <?php echo $booking['status'] == 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                            <option value="cancelled" <?php echo $booking['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </span>
                </div>
                <div class="detail-row">
                    <strong>Created At:</strong>
                    <span><?php echo date('F d, Y g:i A', strtotime($booking['created_at'])); ?></span>
                </div>
                <a href="bookings.php" class="btn btn-primary">Back to All Bookings</a>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Car Model</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($bookings->num_rows > 0): ?>
                        <?php while($booking = $bookings->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $booking['id']; ?></td>
                                <td><?php echo htmlspecialchars($booking['name']); ?></td>
                                <td><?php echo htmlspecialchars($booking['car_model']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($booking['created_at'])); ?></td>
                                <td><span style="padding: 0.25rem 0.5rem; background: #f1faee; border-radius: 3px;"><?php echo ucfirst($booking['status']); ?></span></td>
                                <td><a href="?id=<?php echo $booking['id']; ?>">View</a></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align: center; padding: 2rem;">No bookings found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <script>
        function updateStatus(id, status) {
            if (confirm('Update booking status to ' + status + '?')) {
                window.location.href = '?update_status=1&id=' + id + '&status=' + status;
            }
        }
    </script>
</body>
</html>
<?php $conn->close(); ?>

