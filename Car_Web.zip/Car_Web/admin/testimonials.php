<?php
require_once '../config/config.php';
requireAdminLogin();

$conn = getDBConnection();

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM testimonials WHERE id = $id");
    header('Location: testimonials.php?status=success&message=' . urlencode('Testimonial deleted successfully'));
    exit();
}

// Handle status toggle
if (isset($_GET['toggle_status'])) {
    $id = (int)$_GET['id'];
    $current = $conn->query("SELECT status FROM testimonials WHERE id = $id")->fetch_assoc()['status'];
    $newStatus = $current == 'active' ? 'inactive' : 'active';
    $conn->query("UPDATE testimonials SET status = '$newStatus' WHERE id = $id");
    header('Location: testimonials.php?status=success&message=' . urlencode('Testimonial status updated'));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = $_POST['customer_name'] ?? '';
    $rating = (int)($_POST['rating'] ?? 5);
    $review = $_POST['review'] ?? '';
    $photo = $_POST['photo'] ?? '';
    $status = $_POST['status'] ?? 'active';

    if (isset($_POST['edit_id'])) {
        $id = (int)$_POST['edit_id'];
        $stmt = $conn->prepare("UPDATE testimonials SET customer_name=?, rating=?, review=?, photo=?, status=? WHERE id=?");
        $stmt->bind_param("sissi", $customer_name, $rating, $review, $photo, $status, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO testimonials (customer_name, rating, review, photo, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("siss", $customer_name, $rating, $review, $photo, $status);
    }
    
    if ($stmt->execute()) {
        header('Location: testimonials.php?status=success&message=' . urlencode('Testimonial saved successfully'));
        exit();
    }
    $stmt->close();
}

$testimonials = $conn->query("SELECT * FROM testimonials ORDER BY created_at DESC");
$editing = isset($_GET['edit']) ? $conn->query("SELECT * FROM testimonials WHERE id = " . (int)$_GET['edit'])->fetch_assoc() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Testimonials - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-header {
            background: #1d3557;
            color: #fff;
            padding: 1rem 0;
            margin-bottom: 2rem;
        }
        .admin-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-nav a {
            color: #fff;
            text-decoration: none;
            margin-left: 1rem;
        }
        .form-container {
            background: #fff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        table th, table td {
            padding: 1rem;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        table th {
            background: #f1faee;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <div class="container">
            <div class="admin-nav">
                <h1><i class="fas fa-star"></i> Manage Testimonials</h1>
                <div>
                    <a href="index.php"><i class="fas fa-arrow-left"></i> Dashboard</a>
                    <a href="../index.php"><i class="fas fa-home"></i> View Site</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if (isset($_GET['status'])): ?>
            <div style="padding: 1rem; background: <?php echo $_GET['status'] == 'success' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $_GET['status'] == 'success' ? '#155724' : '#721c24'; ?>; border-radius: 5px; margin-bottom: 1rem;">
                <?php echo htmlspecialchars($_GET['message'] ?? ''); ?>
            </div>
        <?php endif; ?>

        <div class="form-container">
            <h2><?php echo $editing ? 'Edit' : 'Add'; ?> Testimonial</h2>
            <form method="POST" action="">
                <?php if ($editing): ?>
                    <input type="hidden" name="edit_id" value="<?php echo $editing['id']; ?>">
                <?php endif; ?>
                <div class="form-group">
                    <label>Customer Name *</label>
                    <input type="text" name="customer_name" value="<?php echo htmlspecialchars($editing['customer_name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label>Rating *</label>
                    <select name="rating" required>
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <option value="<?php echo $i; ?>" <?php echo ($editing['rating'] ?? 5) == $i ? 'selected' : ''; ?>><?php echo $i; ?> Star<?php echo $i > 1 ? 's' : ''; ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Review *</label>
                    <textarea name="review" rows="4" required><?php echo htmlspecialchars($editing['review'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Photo URL</label>
                    <input type="url" name="photo" value="<?php echo htmlspecialchars($editing['photo'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="active" <?php echo ($editing['status'] ?? 'active') == 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo ($editing['status'] ?? 'active') == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><?php echo $editing ? 'Update' : 'Add'; ?> Testimonial</button>
                <?php if ($editing): ?>
                    <a href="testimonials.php" class="btn btn-outline">Cancel</a>
                <?php endif; ?>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($testimonials->num_rows > 0): ?>
                    <?php while($testimonial = $testimonials->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($testimonial['customer_name']); ?></td>
                            <td>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star" style="color: <?php echo $i <= $testimonial['rating'] ? '#ffc107' : '#ddd'; ?>;"></i>
                                <?php endfor; ?>
                            </td>
                            <td><?php echo htmlspecialchars(substr($testimonial['review'], 0, 100)) . (strlen($testimonial['review']) > 100 ? '...' : ''); ?></td>
                            <td><span style="padding: 0.25rem 0.5rem; background: #f1faee; border-radius: 3px;"><?php echo ucfirst($testimonial['status']); ?></span></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="?edit=<?php echo $testimonial['id']; ?>" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i> Edit</a>
                                    <a href="?toggle_status=1&id=<?php echo $testimonial['id']; ?>" class="btn btn-outline btn-sm">Toggle Status</a>
                                    <a href="?delete=<?php echo $testimonial['id']; ?>" 
                                       class="btn btn-primary btn-sm" 
                                       onclick="return confirm('Are you sure?')"
                                       style="background: #e63946;"><i class="fas fa-trash"></i> Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align: center; padding: 2rem;">No testimonials found</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php $conn->close(); ?>

