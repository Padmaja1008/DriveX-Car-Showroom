<?php
require_once 'config/config.php';
$conn = getDBConnection();

// Get featured cars
$featuredCars = $conn->query("SELECT * FROM cars WHERE status = 'available' ORDER BY created_at DESC LIMIT 3");
$newArrivals = $conn->query("SELECT * FROM cars WHERE status = 'available' ORDER BY created_at DESC LIMIT 6");

// Get testimonials
$testimonials = $conn->query("SELECT * FROM testimonials WHERE status = 'active' ORDER BY created_at DESC LIMIT 3");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Banner -->
    <section class="hero">
        <div class="hero-content">
            <h1>Find Your Dream Car</h1>
            <p>Premium vehicles at unbeatable prices. Experience luxury and performance.</p>
            <div class="hero-buttons">
                <a href="cars.php" class="btn btn-primary">Explore Cars</a>
                <a href="contact.php" class="btn btn-secondary">Book Test Drive</a>
            </div>
        </div>
        <div class="hero-image">
            <img src="assets/images/hero-car.jpg" alt="Premium Car" onerror="this.src='https://via.placeholder.com/800x500?text=Premium+Car'">
        </div>
    </section>

    <!-- Offers Section -->
    <section class="offers-section">
        <div class="container">
            <h2 class="section-title">Special Offers</h2>
            <div class="offers-grid">
                <div class="offer-card">
                    <i class="fas fa-tag"></i>
                    <h3>Up to 15% Off</h3>
                    <p>On selected models this month</p>
                </div>
                <div class="offer-card">
                    <i class="fas fa-car"></i>
                    <h3>Free Test Drive</h3>
                    <p>Book your test drive today</p>
                </div>
                <div class="offer-card">
                    <i class="fas fa-shield-alt"></i>
                    <h3>Extended Warranty</h3>
                    <p>5 years warranty on all new cars</p>
                </div>
                <div class="offer-card">
                    <i class="fas fa-percent"></i>
                    <h3>Low EMI Options</h3>
                    <p>Starting from ₹15,000/month</p>
                </div>
            </div>
        </div>
    </section>

    <!-- New Arrivals -->
    <section class="new-arrivals">
        <div class="container">
            <h2 class="section-title">New Arrivals</h2>
            <div class="cars-grid">
                <?php if ($newArrivals->num_rows > 0): ?>
                    <?php while($car = $newArrivals->fetch_assoc()): ?>
                        <div class="car-card">
                            <div class="car-image">
                                <img src="<?php echo htmlspecialchars($car['image'] ?: 'assets/images/car-placeholder.jpg'); ?>" 
                                     alt="<?php echo htmlspecialchars($car['name']); ?>"
                                     onerror="this.src='https://via.placeholder.com/400x300?text=Car+Image'">
                                <span class="car-status"><?php echo ucfirst($car['status']); ?></span>
                            </div>
                            <div class="car-info">
                                <h3><?php echo htmlspecialchars($car['name']); ?></h3>
                                <p class="car-model"><?php echo htmlspecialchars($car['model']); ?> - <?php echo $car['year']; ?></p>
                                <div class="car-specs">
                                    <span><i class="fas fa-gas-pump"></i> <?php echo htmlspecialchars($car['fuel_type']); ?></span>
                                    <span><i class="fas fa-cog"></i> <?php echo htmlspecialchars($car['transmission']); ?></span>
                                    <span><i class="fas fa-tachometer-alt"></i> <?php echo htmlspecialchars($car['mileage']); ?></span>
                                </div>
                                <div class="car-price">₹<?php echo number_format($car['price'], 2); ?></div>
                                <a href="car-details.php?id=<?php echo $car['id']; ?>" class="btn btn-primary btn-block">View Details</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="no-cars">No cars available at the moment. Check back soon!</p>
                <?php endif; ?>
            </div>
            <div class="text-center" style="margin-top: 2rem;">
                <a href="cars.php" class="btn btn-outline">View All Cars</a>
            </div>
        </div>
    </section>

    <!-- Why Choose Us -->
    <section class="why-choose-us">
        <div class="container">
            <h2 class="section-title">Why Choose Us</h2>
            <div class="features-grid">
                <div class="feature-item">
                    <i class="fas fa-certificate"></i>
                    <h3>Trusted Dealer</h3>
                    <p>15+ years of experience in the automotive industry</p>
                </div>
                <div class="feature-item">
                    <i class="fas fa-star"></i>
                    <h3>Quality Assurance</h3>
                    <p>All vehicles undergo rigorous quality checks</p>
                </div>
                <div class="feature-item">
                    <i class="fas fa-tools"></i>
                    <h3>Expert Service</h3>
                    <p>Professional maintenance and support team</p>
                </div>
                <div class="feature-item">
                    <i class="fas fa-handshake"></i>
                    <h3>Best Prices</h3>
                    <p>Competitive pricing with flexible payment options</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials-section">
        <div class="container">
            <h2 class="section-title">What Our Customers Say</h2>
            <div class="testimonials-grid">
                <?php if ($testimonials->num_rows > 0): ?>
                    <?php while($testimonial = $testimonials->fetch_assoc()): ?>
                        <div class="testimonial-card">
                            <div class="testimonial-rating">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star <?php echo $i <= $testimonial['rating'] ? 'active' : ''; ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <p class="testimonial-text">"<?php echo htmlspecialchars($testimonial['review']); ?>"</p>
                            <div class="testimonial-author">
                                <?php if($testimonial['photo']): ?>
                                    <img src="<?php echo htmlspecialchars($testimonial['photo']); ?>" alt="<?php echo htmlspecialchars($testimonial['customer_name']); ?>">
                                <?php endif; ?>
                                <span><?php echo htmlspecialchars($testimonial['customer_name']); ?></span>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="no-testimonials">No testimonials available yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>
<?php $conn->close(); ?>

