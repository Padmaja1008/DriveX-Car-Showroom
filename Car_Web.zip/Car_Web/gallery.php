<?php
require_once 'config/config.php';
$conn = getDBConnection();

// Get cars for gallery
$cars = $conn->query("SELECT id, name, model, image, images FROM cars WHERE status = 'available' ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-header">
        <div class="container">
            <h1>Gallery</h1>
            <p>Explore our showroom, cars, and events</p>
        </div>
    </section>

    <section class="gallery-content">
        <div class="container">
            <div class="gallery-filters">
                <button class="filter-btn active" onclick="filterGallery('all')">All</button>
                <button class="filter-btn" onclick="filterGallery('showroom')">Showroom</button>
                <button class="filter-btn" onclick="filterGallery('cars')">Cars</button>
                <button class="filter-btn" onclick="filterGallery('events')">Events</button>
                <button class="filter-btn" onclick="filterGallery('deliveries')">Deliveries</button>
            </div>

            <div class="gallery-grid">
                <!-- Showroom Images -->
                <div class="gallery-item" data-category="showroom">
                    <img src="assets/images/showroom-1.jpg" alt="Showroom" onerror="this.src='https://via.placeholder.com/400x300?text=Showroom'">
                    <div class="gallery-overlay">
                        <h3>Our Showroom</h3>
                        <p>Modern and spacious showroom</p>
                    </div>
                </div>
                <div class="gallery-item" data-category="showroom">
                    <img src="assets/images/showroom-2.jpg" alt="Showroom" onerror="this.src='https://via.placeholder.com/400x300?text=Showroom'">
                    <div class="gallery-overlay">
                        <h3>Service Center</h3>
                        <p>State-of-the-art service facility</p>
                    </div>
                </div>

                <!-- Car Images -->
                <?php if ($cars->num_rows > 0): ?>
                    <?php while($car = $cars->fetch_assoc()): ?>
                        <?php 
                        $carImages = [];
                        if ($car['images']) {
                            $carImages = json_decode($car['images'], true);
                        }
                        if ($car['image']) {
                            array_unshift($carImages, $car['image']);
                        }
                        if (empty($carImages)) {
                            $carImages = ['https://via.placeholder.com/400x300?text=' . urlencode($car['name'])];
                        }
                        foreach($carImages as $img):
                        ?>
                            <div class="gallery-item" data-category="cars">
                                <img src="<?php echo htmlspecialchars($img); ?>" alt="<?php echo htmlspecialchars($car['name']); ?>" onerror="this.src='https://via.placeholder.com/400x300?text=Car'">
                                <div class="gallery-overlay">
                                    <h3><?php echo htmlspecialchars($car['name']); ?></h3>
                                    <p><?php echo htmlspecialchars($car['model']); ?></p>
                                    <a href="car-details.php?id=<?php echo $car['id']; ?>" class="btn btn-sm btn-primary">View Details</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endwhile; ?>
                <?php endif; ?>

                <!-- Event Images -->
                <div class="gallery-item" data-category="events">
                    <img src="assets/images/event-1.jpg" alt="Event" onerror="this.src='https://via.placeholder.com/400x300?text=Event'">
                    <div class="gallery-overlay">
                        <h3>Car Launch Event</h3>
                        <p>New model launch celebration</p>
                    </div>
                </div>
                <div class="gallery-item" data-category="events">
                    <img src="assets/images/event-2.jpg" alt="Event" onerror="this.src='https://via.placeholder.com/400x300?text=Event'">
                    <div class="gallery-overlay">
                        <h3>Customer Meet</h3>
                        <p>Annual customer appreciation event</p>
                    </div>
                </div>

                <!-- Delivery Images -->
                <div class="gallery-item" data-category="deliveries">
                    <img src="assets/images/delivery-1.jpg" alt="Delivery" onerror="this.src='https://via.placeholder.com/400x300?text=Delivery'">
                    <div class="gallery-overlay">
                        <h3>Happy Customer</h3>
                        <p>New car delivery ceremony</p>
                    </div>
                </div>
                <div class="gallery-item" data-category="deliveries">
                    <img src="assets/images/delivery-2.jpg" alt="Delivery" onerror="this.src='https://via.placeholder.com/400x300?text=Delivery'">
                    <div class="gallery-overlay">
                        <h3>Family Delivery</h3>
                        <p>Celebrating with our customers</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Lightbox Modal -->
    <div id="lightboxModal" class="lightbox-modal">
        <span class="lightbox-close">&times;</span>
        <img class="lightbox-content" id="lightboxImage">
        <div class="lightbox-caption" id="lightboxCaption"></div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
    <script>
        function filterGallery(category) {
            const items = document.querySelectorAll('.gallery-item');
            const buttons = document.querySelectorAll('.filter-btn');
            
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            items.forEach(item => {
                if (category === 'all' || item.dataset.category === category) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        // Lightbox functionality
        document.querySelectorAll('.gallery-item img').forEach(img => {
            img.addEventListener('click', function() {
                const modal = document.getElementById('lightboxModal');
                const modalImg = document.getElementById('lightboxImage');
                const caption = document.getElementById('lightboxCaption');
                
                modal.style.display = 'block';
                modalImg.src = this.src;
                caption.textContent = this.alt;
            });
        });

        document.querySelector('.lightbox-close').addEventListener('click', function() {
            document.getElementById('lightboxModal').style.display = 'none';
        });

        document.getElementById('lightboxModal').addEventListener('click', function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>

