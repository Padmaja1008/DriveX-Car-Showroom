<header class="main-header">
    <div class="container">
        <div class="header-content">
            <div class="logo">
                <a href="index.php">
                    <i class="fas fa-car"></i>
                    <span><?php echo SITE_NAME; ?></span>
                </a>
            </div>
            <nav class="main-nav" id="mainNav">
                <a href="index.php" class="nav-link active">Home</a>
                <a href="cars.php" class="nav-link">Cars</a>
                <a href="about.php" class="nav-link">About Us</a>
                <a href="services.php" class="nav-link">Services</a>
                <a href="gallery.php" class="nav-link">Gallery</a>
                <a href="testimonials.php" class="nav-link">Testimonials</a>
                <a href="contact.php" class="nav-link">Contact</a>
            </nav>
            <div class="header-actions">
                <a href="contact.php" class="btn btn-primary btn-sm">Book Test Drive</a>
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </div>
</header>

