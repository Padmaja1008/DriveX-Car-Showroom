<?php
require_once 'config/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-header">
        <div class="container">
            <h1>About Us</h1>
            <p>Your trusted partner in the automotive world</p>
        </div>
    </section>

    <section class="about-content">
        <div class="container">
            <div class="about-section">
                <div class="about-text">
                    <h2>Our Story</h2>
                    <p>Founded in 2008, <?php echo SITE_NAME; ?> has been a leading name in the automotive industry for over 15 years. What started as a small family business has grown into one of the most trusted car dealerships in the region.</p>
                    <p>We have successfully served thousands of satisfied customers, helping them find their perfect vehicle. Our commitment to quality, transparency, and customer satisfaction has been the cornerstone of our success.</p>
                    <p>Over the years, we have expanded our services to include not just car sales, but also financing, insurance, servicing, and comprehensive after-sales support. We believe in building long-term relationships with our customers.</p>
                </div>
                <div class="about-image">
                    <img src="assets/images/showroom.jpg" alt="Our Showroom" onerror="this.src='https://via.placeholder.com/600x400?text=Our+Showroom'">
                </div>
            </div>

            <div class="mission-vision">
                <div class="mission-card">
                    <i class="fas fa-bullseye"></i>
                    <h3>Our Mission</h3>
                    <p>To provide exceptional automotive solutions with integrity, transparency, and unmatched customer service. We strive to make car ownership accessible, enjoyable, and hassle-free for everyone.</p>
                </div>
                <div class="vision-card">
                    <i class="fas fa-eye"></i>
                    <h3>Our Vision</h3>
                    <p>To become the most trusted and preferred automotive dealership, known for innovation, quality, and customer-centric approach. We aim to set new standards in the automotive retail industry.</p>
                </div>
            </div>

            <div class="why-choose-section">
                <h2 class="section-title">Why Choose Us</h2>
                <div class="features-grid">
                    <div class="feature-item">
                        <i class="fas fa-certificate"></i>
                        <h3>Trusted Dealer</h3>
                        <p>15+ years of experience with thousands of satisfied customers</p>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-star"></i>
                        <h3>Quality Assurance</h3>
                        <p>All vehicles undergo rigorous quality checks and certification</p>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-tools"></i>
                        <h3>Expert Service</h3>
                        <p>Professional team with extensive automotive knowledge</p>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-handshake"></i>
                        <h3>Best Prices</h3>
                        <p>Competitive pricing with flexible payment options</p>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-shield-alt"></i>
                        <h3>Warranty & Support</h3>
                        <p>Comprehensive warranty and 24/7 roadside assistance</p>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-users"></i>
                        <h3>Customer First</h3>
                        <p>Dedicated customer support and personalized service</p>
                    </div>
                </div>
            </div>

            <div class="stats-section">
                <h2 class="section-title">Our Achievements</h2>
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-number">15+</div>
                        <div class="stat-label">Years of Experience</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">5000+</div>
                        <div class="stat-label">Happy Customers</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">500+</div>
                        <div class="stat-label">Cars Sold</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">4.8</div>
                        <div class="stat-label">Average Rating</div>
                    </div>
                </div>
            </div>

            <div class="team-section">
                <h2 class="section-title">Our Team</h2>
                <div class="team-grid">
                    <div class="team-member">
                        <div class="member-photo">
                            <i class="fas fa-user"></i>
                        </div>
                        <h3>John Smith</h3>
                        <p class="member-role">CEO & Founder</p>
                        <p>20+ years of experience in automotive industry</p>
                    </div>
                    <div class="team-member">
                        <div class="member-photo">
                            <i class="fas fa-user"></i>
                        </div>
                        <h3>Sarah Johnson</h3>
                        <p class="member-role">Sales Director</p>
                        <p>Expert in customer relations and sales strategy</p>
                    </div>
                    <div class="team-member">
                        <div class="member-photo">
                            <i class="fas fa-user"></i>
                        </div>
                        <h3>Mike Davis</h3>
                        <p class="member-role">Service Manager</p>
                        <p>Certified automotive technician and service expert</p>
                    </div>
                    <div class="team-member">
                        <div class="member-photo">
                            <i class="fas fa-user"></i>
                        </div>
                        <h3>Emily Brown</h3>
                        <p class="member-role">Finance Advisor</p>
                        <p>Specialized in automotive financing solutions</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>

