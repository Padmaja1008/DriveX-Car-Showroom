<?php
require_once 'config/config.php';
$conn = getDBConnection();

// Get filter parameters
$search = isset($_GET['search']) ? $_GET['search'] : '';
$fuel_type = isset($_GET['fuel_type']) ? $_GET['fuel_type'] : '';
$transmission = isset($_GET['transmission']) ? $_GET['transmission'] : '';
$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : '';
$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : '';

// Build query
$query = "SELECT * FROM cars WHERE status = 'available'";
$params = [];

if ($search) {
    $query .= " AND (name LIKE ? OR model LIKE ?)";
    $searchParam = "%$search%";
}

if ($fuel_type) {
    $query .= " AND fuel_type = ?";
}

if ($transmission) {
    $query .= " AND transmission = ?";
}

if ($min_price) {
    $query .= " AND price >= ?";
}

if ($max_price) {
    $query .= " AND price <= ?";
}

$query .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($query);
if ($stmt) {
    $types = '';
    $bindParams = [];
    
    if ($search) {
        $types .= 'ss';
        $bindParams[] = $searchParam;
        $bindParams[] = $searchParam;
    }
    if ($fuel_type) {
        $types .= 's';
        $bindParams[] = $fuel_type;
    }
    if ($transmission) {
        $types .= 's';
        $bindParams[] = $transmission;
    }
    if ($min_price) {
        $types .= 'd';
        $bindParams[] = $min_price;
    }
    if ($max_price) {
        $types .= 'd';
        $bindParams[] = $max_price;
    }
    
    if (!empty($bindParams)) {
        $stmt->bind_param($types, ...$bindParams);
    }
    
    $stmt->execute();
    $cars = $stmt->get_result();
} else {
    $cars = $conn->query("SELECT * FROM cars WHERE status = 'available' ORDER BY created_at DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cars - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section class="page-header">
        <div class="container">
            <h1>Our Car Collection</h1>
            <p>Browse through our extensive collection of premium vehicles</p>
        </div>
    </section>

    <section class="cars-listing">
        <div class="container">
            <!-- Filters -->
            <div class="filters-section">
                <form method="GET" action="cars.php" class="filters-form">
                    <div class="filter-group">
                        <input type="text" name="search" placeholder="Search by name or model..." value="<?php echo htmlspecialchars($search); ?>" class="filter-input">
                    </div>
                    <div class="filter-group">
                        <select name="fuel_type" class="filter-select">
                            <option value="">All Fuel Types</option>
                            <option value="Petrol" <?php echo $fuel_type == 'Petrol' ? 'selected' : ''; ?>>Petrol</option>
                            <option value="Diesel" <?php echo $fuel_type == 'Diesel' ? 'selected' : ''; ?>>Diesel</option>
                            <option value="Electric" <?php echo $fuel_type == 'Electric' ? 'selected' : ''; ?>>Electric</option>
                            <option value="Hybrid" <?php echo $fuel_type == 'Hybrid' ? 'selected' : ''; ?>>Hybrid</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <select name="transmission" class="filter-select">
                            <option value="">All Transmissions</option>
                            <option value="Automatic" <?php echo $transmission == 'Automatic' ? 'selected' : ''; ?>>Automatic</option>
                            <option value="Manual" <?php echo $transmission == 'Manual' ? 'selected' : ''; ?>>Manual</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <input type="number" name="min_price" placeholder="Min Price" value="<?php echo htmlspecialchars($min_price); ?>" class="filter-input">
                    </div>
                    <div class="filter-group">
                        <input type="number" name="max_price" placeholder="Max Price" value="<?php echo htmlspecialchars($max_price); ?>" class="filter-input">
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="cars.php" class="btn btn-outline">Reset</a>
                    </div>
                </form>
            </div>

            <!-- Cars Grid -->
            <div class="cars-grid">
                <?php if ($cars->num_rows > 0): ?>
                    <?php while($car = $cars->fetch_assoc()): ?>
                        <div class="car-card">
                            <div class="car-image">
                                <img src="<?php echo htmlspecialchars($car['image'] ?: 'assets/images/car-placeholder.jpg'); ?>" 
                                     alt="<?php echo htmlspecialchars($car['name']); ?>"
                                     onerror="this.src='https://via.placeholder.com/400x300?text=Car+Image'">
                                <span class="car-status"><?php echo ucfirst($car['status']); ?></span>
                            </div>
                            <div class="car-info">
                                <h3><?php echo htmlspecialchars($car['name']); ?></h3>
                                <p class="car-model"><?php echo htmlspecialchars($car['model']); ?> - <?php echo $car['year']; ?></p>
                                <div class="car-specs">
                                    <span><i class="fas fa-gas-pump"></i> <?php echo htmlspecialchars($car['fuel_type']); ?></span>
                                    <span><i class="fas fa-cog"></i> <?php echo htmlspecialchars($car['transmission']); ?></span>
                                    <span><i class="fas fa-tachometer-alt"></i> <?php echo htmlspecialchars($car['mileage']); ?></span>
                                </div>
                                <div class="car-price">₹<?php echo number_format($car['price'], 2); ?></div>
                                <a href="car-details.php?id=<?php echo $car['id']; ?>" class="btn btn-primary btn-block">View Details</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="no-cars">
                        <i class="fas fa-car-side"></i>
                        <h3>No cars found</h3>
                        <p>Try adjusting your filters or check back later.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
    <script src="assets/js/main.js"></script>
</body>
</html>
<?php 
if (isset($stmt)) $stmt->close();
$conn->close(); 
?>

