<?php
session_start();
require_once 'database.php';

// Site configuration
define('SITE_NAME', 'Premium Car Showroom');
define('SITE_URL', 'http://localhost/Car_Web');

// Admin authentication check
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']);
}

function requireAdminLogin() {
    if (!isAdminLoggedIn()) {
        header('Location: ' . SITE_URL . '/admin/login.php');
        exit();
    }
}
?>

