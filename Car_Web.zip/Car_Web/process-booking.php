<?php
require_once 'config/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $car_id = $_POST['car_id'] ?? null;
    $car_model = $_POST['car_model'] ?? '';
    $message = $_POST['message'] ?? '';
    $preferred_date = $_POST['preferred_date'] ?? null;
    $preferred_time = $_POST['preferred_time'] ?? null;

    if (empty($name) || empty($phone) || empty($email)) {
        header('Location: contact.php?status=error&message=' . urlencode('Please fill in all required fields.'));
        exit();
    }

    $conn = getDBConnection();
    
    $stmt = $conn->prepare("INSERT INTO bookings (name, phone, email, car_id, car_model, message, preferred_date, preferred_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssissss", $name, $phone, $email, $car_id, $car_model, $message, $preferred_date, $preferred_time);
    
    if ($stmt->execute()) {
        header('Location: index.php?status=success&message=' . urlencode('Booking request submitted successfully! We will contact you soon.'));
    } else {
        header('Location: contact.php?status=error&message=' . urlencode('Error submitting booking. Please try again.'));
    }
    
    $stmt->close();
    $conn->close();
} else {
    header('Location: index.php');
}
exit();

